#ifndef MODIFICARESTOC_H
#define MODIFICARESTOC_H

#include <QWidget>
#include <QTcpSocket>
#include <QMessageBox>
#include "logger.h"

namespace Ui {
class ModificareStoc;
}

class ModificareStoc : public QWidget
{
    Q_OBJECT

public:
    explicit ModificareStoc(QWidget *parent = nullptr);
    ~ModificareStoc();

private slots:
    void on_bModifica_clicked();

    void on_butoninapoi_clicked();

private:
    Ui::ModificareStoc *ui;
    QTcpSocket* socket= new QTcpSocket();
    QString codprodus,stoc,magazin,codOperatiune;
    logger* a=new logger();

};

#endif // MODIFICARESTOC_H
