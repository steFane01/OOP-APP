#ifndef OPTIUNIPRODUS_H
#define OPTIUNIPRODUS_H

#include <QWidget>
#include <QTcpSocket>
#include "logger.h"

namespace Ui {
class OptiuniProdus;
}

class OptiuniProdus : public QWidget
{
    Q_OBJECT

public:
    explicit OptiuniProdus(const QString& denumireProdus,const QString& cod, QWidget *parent = nullptr);
    ~OptiuniProdus();

private slots:
    void on_bRezerva_clicked();

    void on_bInapoi_clicked();

private:
    Ui::OptiuniProdus *ui;
    QTcpSocket* socket = new QTcpSocket();
    QString numeProdus,cod,magazin,codOperatiune;
    logger* a=new logger();

};

#endif // OPTIUNIPRODUS_H
