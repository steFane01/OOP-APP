#include "mainwindow.h"
#include "angajatmainpage.h"
#include "achizitiimainpage.h"
#include "ui_mainwindow.h"
#include "logger.h"
#include <QtSql>
#include <QPixmap>
#include <QLabel>
#include <QLineEdit>
#include <QTcpSocket>
#include <QApplication>
#include <QObject>
#include <QJsonObject>
#include <QPalette>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    QPixmap pix("C:/Users/sebas/Downloads/GheSku.jpg");
    ui->label_pic->setPixmap(pix.scaled(201,201,Qt::KeepAspectRatio));
    setWindowIcon(QIcon("C:/Users/sebas/Downloads/GheSku.jpg"));
    ui->parola->setEchoMode(QLineEdit::Password);
    setWindowTitle("GheSku MainWindow");
    QPixmap backgroundImage("C:/Users/sebas/OneDrive/Desktop/fundal2.jpg");
    QPalette palette;
    palette.setBrush(QPalette::Window, backgroundImage);
    this->setStyleSheet("MainWindow { background-image: url(C:/Users/sebas/OneDrive/Desktop/fundal2.jpg); }");
    this->setPalette(palette);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_conectare_clicked()
{
    username = ui->user->text();
    password = ui->parola->text();
    codOperatiune="0";

    socket = new QTcpSocket(this);
    socket->connectToHost("127.0.0.1", 1234);

    if (socket->waitForConnected(5000)) {
        qDebug() << "Conectat cu succes la server";
        QByteArray data = QString("%1:%2:%3").arg(username, password,codOperatiune).toUtf8();

        socket->write(data);
        socket->flush();

        connect(socket, SIGNAL(readyRead()), this, SLOT(onResponseReceived()));
    } else {
        qDebug() << "Conectarea la server a eșuat:" << socket->errorString();
        QMessageBox::warning(this, "Eroare", "Conectarea la server a eșuat");
        socket->deleteLater();
    }
}

void MainWindow::onResponseReceived()
{
    AchizitiiMainPage* administrator=new AchizitiiMainPage();
    AngajatMainPage* angajat=new AngajatMainPage();
    QByteArray response = socket->readAll();
    if (response == "autentificat ca si Administrator") {
        qDebug() << "Autentificare Administrator cu succes";
        this->hide();
        administrator->show();
        a->scrieMesaj("S-a conectat administratorul " + this->username);
    } else {
        if(response=="autentificat ca si Lucrator comercial")
        {
            qDebug()<<" Autentificare Lucrator Comercial cu succes";
            this->hide();
            angajat->show();
            //qDebug()<<this->username<<" "<<this->username;
            a->scrieMesaj("S-a conectat lucratorul comercial "+this->username);
        }
        else{
        qDebug() << "Autentificare esuata";
        }
    }
    socket->disconnectFromHost();
    socket->deleteLater();
}
