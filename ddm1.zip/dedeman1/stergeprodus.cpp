#include "stergeprodus.h"
#include "ui_stergeprodus.h"
#include "achizitiimainpage.h"
#include <QMessageBox>
#include <QTimer>

StergeProdus::StergeProdus(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::StergeProdus)
{
    ui->setupUi(this);
    setWindowTitle("Stergere produs");
    setWindowIcon(QIcon("C:/Users/sebas/Downloads/GheSku.jpg"));
}

StergeProdus::~StergeProdus()
{
    delete ui;
}


void StergeProdus::on_btnInapoi_clicked()
{
    AchizitiiMainPage* administrator=new AchizitiiMainPage();
    this->hide();
    administrator->show();
}


void StergeProdus::on_bSterge_clicked()
{
    codProdus=ui->lineCodProdus->text();
    magazin=ui->comboBox->currentText();

    ui->lineCodProdus->clear();
    codOperatiune="701";

    socket->connectToHost("127.0.0.1",1234);
    if(socket->waitForConnected())
    {
        QByteArray data = QString("%1:%2:%3").arg(codProdus,magazin,codOperatiune).toUtf8();
        socket->write(data);
        socket->waitForBytesWritten();

        socket->waitForReadyRead();
        QByteArray responseData = socket->readAll();
        QString responseString(responseData);
        if(responseString=="701 succes")
        {
            QMessageBox* msgBox = new QMessageBox(QMessageBox::Information, "Stergere produs", "Produsul a fost sters cu succes");
            msgBox->setWindowTitle("Stergere Produs");
            msgBox->setDefaultButton(QMessageBox::NoButton);
            msgBox->setStyleSheet("QMessageBox {background-color: #F4661B;}");
            QTimer::singleShot(1000, msgBox, &QMessageBox::accept); // 5000 ms = 5 secunde
            msgBox->exec();
            a->scrieMesaj("A fost sters produsul cu id "+this->codProdus+" din "+this->magazin);
        }
        if(responseString=="701 lipsa")
        {
            QMessageBox* msgBox = new QMessageBox(QMessageBox::Information, "Stergere Produs", "Produsul nu exista in gestiunea magazinului");
            msgBox->setWindowTitle("Stergere Produs");
            msgBox->setDefaultButton(QMessageBox::NoButton);
            msgBox->setStyleSheet("QMessageBox {background-color: #F4661B;}");
            QTimer::singleShot(1000, msgBox, &QMessageBox::accept); // 5000 ms = 5 secunde
            msgBox->exec();
            a->scrieMesaj("S-a incercat stergerea produsului cu id "+this->codProdus+" din "+this->magazin);
        }

    }
}
