#include "angajatmainpage.h"
#include "adaugaprodus.h"
#include "rezervaprodus.h"
#include "ui_angajatmainpage.h"
#include "cautaprodus.h"
#include "mainwindow.h"

AngajatMainPage::AngajatMainPage(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AngajatMainPage)
{
    ui->setupUi(this);
    setWindowTitle("Lucrator Comercial");
    setWindowIcon(QIcon("C:/Users/sebas/Downloads/GheSku.jpg"));
    QPixmap pix("C:/Users/sebas/Downloads/GheSku.jpg");
    ui->label_pic->setPixmap(pix.scaled(201,201,Qt::KeepAspectRatio));
}

AngajatMainPage::~AngajatMainPage()
{
    delete ui;
}

void AngajatMainPage::on_bCautaProdus_clicked()
{
    CautaProdus* cautaProdus=new CautaProdus();
    this->hide();
    cautaProdus->show();

}

void AngajatMainPage::on_bInapoi_clicked()
{
    MainWindow* mainWindow= new MainWindow();
    this->hide();
    mainWindow->show();
    a->scrieMesaj("Lucratorul comercial s-a deconectat");
}


void AngajatMainPage::on_pushButton_clicked()
{
    AdaugaProdus* adaugaprodus= new AdaugaProdus();
    this->hide();
    adaugaprodus->show();
}




void AngajatMainPage::on_bRezerva_clicked()
{
    RezervaProdus* rzv = new RezervaProdus();
    this->hide();
    rzv->show();
}

