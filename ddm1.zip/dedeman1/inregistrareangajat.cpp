#include "inregistrareangajat.h"
#include "ui_inregistrareangajat.h"

InregistrareAngajat::InregistrareAngajat(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::InregistrareAngajat)
{
    ui->setupUi(this);
}

InregistrareAngajat::~InregistrareAngajat()
{
    delete ui;
}
