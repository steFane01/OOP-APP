#ifndef ANGAJATMAINPAGE_H
#define ANGAJATMAINPAGE_H

#include <QWidget>
#include "logger.h"

namespace Ui {
class AngajatMainPage;
}

class AngajatMainPage : public QWidget
{
    Q_OBJECT

public:
    explicit AngajatMainPage(QWidget *parent = nullptr);
    ~AngajatMainPage();

private slots:
    void on_bCautaProdus_clicked();
    void on_bInapoi_clicked();

    void on_pushButton_clicked();

    void on_bRezerva_clicked();

private:
    Ui::AngajatMainPage *ui;
    logger* a=new logger();
};

#endif // ANGAJATMAINPAGE_H
