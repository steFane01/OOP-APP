#include "adaugaprodus.h"
#include "ui_adaugaprodus.h"
#include "achizitiimainpage.h"
#include "QSql"
#include "QSqlQuery"
#include "QSqlError"
#include "QMessageBox"
#include "QTimer"

AdaugaProdus::AdaugaProdus(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AdaugaProdus)
{
    ui->setupUi(this);
    setWindowTitle("Adaugare produs");
    setWindowIcon(QIcon("C:/Users/sebas/Downloads/GheSku.jpg"));
}

AdaugaProdus::~AdaugaProdus()
{
    delete ui;
}


void AdaugaProdus::on_butonadauga_clicked()
{
    denumire = ui->lineDenumire->text();
    codprodus = ui->lineCodProdus->text();
    producator = ui->lineProducator->text();
    pret = ui->linePret->text();
    stoc = ui->lineStoc->text();
    ui->lineDenumire->clear();
    ui->lineProducator->clear();
    ui->linePret->clear();
    ui->lineCodProdus->clear();
    ui->lineStoc->clear();
    magazin = ui->comboBox->currentText();

    codOperatiune = "700";
    this->socket->connectToHost("127.0.0.1",1234);
    if(socket->waitForConnected())
    {
        QByteArray data = QString("%1:%2:%3:%4:%5:%6:%7").arg(denumire,codprodus,producator,pret,stoc,magazin,codOperatiune).toUtf8();
        socket->write(data);
        socket->waitForBytesWritten();

        socket->waitForReadyRead();
        QByteArray responseData = socket->readAll();
        QString responseString(responseData);
        if(responseString=="700 succes")
        {
            QMessageBox* msgBox = new QMessageBox(QMessageBox::Information, "Adaugare produs", "Produsul a fost adaugat cu succes");
            msgBox->setWindowTitle("Adaugare produs");
            msgBox->setDefaultButton(QMessageBox::NoButton);
            msgBox->setStyleSheet("QMessageBox {background-color: #F4661B;}");
            QTimer::singleShot(1000, msgBox, &QMessageBox::accept); // 5000 ms = 5 secunde
            msgBox->exec();
            a->scrieMesaj("A fost adaugat produsul cu id "+this->codprodus + " in "+this->magazin);
        }
        if(responseString=="700 duplicat")
        {
            QMessageBox* msgBox = new QMessageBox(QMessageBox::Information, "Adaugare produs", "Produsul nu a fos adaugat");
            msgBox->setWindowTitle("Adaugare produs");
            msgBox->setDefaultButton(QMessageBox::NoButton);
            msgBox->setStyleSheet("QMessageBox {background-color: #F4661B;}");
            QTimer::singleShot(1000, msgBox, &QMessageBox::accept); // 5000 ms = 5 secunde
            msgBox->exec();
            a->scrieMesaj("S-a incercat duplicarea produsului cu id "+this->codprodus+" in "+this->magazin);
        }
    }
    else
    {
        qDebug()<<"Eroare.";
    }

}

void AdaugaProdus::trimiteMesaj()
{
    this->socket->connectToHost("127.0.0.1",1234);
    this->socket->write("700");
    this->socket->disconnectFromHost();
}
void AdaugaProdus::on_butoninapoi_clicked()
{
    AchizitiiMainPage* administrator= new AchizitiiMainPage();
    this->hide();
    administrator->show();
}

