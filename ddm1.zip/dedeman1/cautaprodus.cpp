#include "cautaprodus.h"
#include "ui_cautaprodus.h"
#include "angajatmainpage.h"
#include "optiuniprodus.h"
#include <QtSql>
#include <QTcpSocket>
#include <QLineEdit>
#include <QPixmap>
#include <QLabel>
#include <QMessageBox>
#include <string.h>
#include <QVBoxLayout>
#include <QHeaderView>


CautaProdus::CautaProdus(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::CautaProdus)
{
    ui->setupUi(this);
    setWindowTitle("Cautare Produs");
    setWindowIcon(QIcon("C:/Users/sebas/Downloads/GheSku.jpg"));

}

CautaProdus::~CautaProdus()
{
    delete ui;
}

void CautaProdus::on_bCautaProdus_clicked()
{
    socket = new QTcpSocket(this);
    socket->connectToHost("127.0.0.1", 1234);
    if (socket->waitForConnected()) {
        denumire = ui->denumireProdus->text();
        ui->denumireProdus->clear();
        codOperatiune = "57";
        QByteArray data = QString("%1:%2").arg(denumire, codOperatiune).toUtf8();
        socket->write(data);
        socket->waitForBytesWritten();

        socket->waitForReadyRead();
        QByteArray responseData = socket->readAll();
        QString responseString(responseData);
        bool check=true;
        if(responseString=="57 lipsa")
        {
            QMessageBox* msgBox = new QMessageBox(QMessageBox::Information, "Cautare Produs", "Produsul cautat nu exista in gestiunea magazinului");
            msgBox->setWindowTitle("Cautare Produs");
            msgBox->setDefaultButton(QMessageBox::NoButton);
            msgBox->setStyleSheet("QMessageBox {background-color: #F4661B;}");
            QTimer::singleShot(1000, msgBox, &QMessageBox::accept); // 5000 ms = 5 secunde
            msgBox->exec();
            check=false;
        }
        if(check==true){
        QStringList splitResult = responseString.split(",");

        // Crearea QTableWidget și setarea numărului de rânduri și coloane
        tableWidget = new QTableWidget(splitResult.size() / 7, 7, this);
        tableWidget->setHorizontalHeaderLabels({"Cod", "Denumire", "Producator", "Pret", "Baneasa", "Ghencea", "Pantelimon"});
        tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

        int currentRow = 0;
        int currentColumn = 0;
        for (int i = 0; i < splitResult.size(); i++) {
            QString currentString = splitResult.at(i);
            QTableWidgetItem *item = new QTableWidgetItem(currentString.trimmed());
            tableWidget->setItem(currentRow, currentColumn, item);

            if (currentColumn == 6) {
                currentRow++;
                currentColumn = 0;
            } else {
                currentColumn++;
            }
        }

        // Redimensionează coloanele pentru a afișa conținutul complet
        tableWidget->resizeColumnsToContents();
        a->scrieMesaj("S-a cautat produsul "+this->denumire+" in toate magazinele");
        QWidget *window = new QWidget;
        QVBoxLayout *layout = new QVBoxLayout(window);
        layout->addWidget(tableWidget);
        window->setLayout(layout);

        int width = tableWidget->horizontalHeader()->length() + 1000;
        int height = tableWidget->verticalHeader()->length() + tableWidget->horizontalHeader()->height() + 200;
        window->resize(width, height);
        window->show();

        // Conectează semnalul cellDoubleClicked doar pentru coloana "Denumire"
        connect(tableWidget, &QTableWidget::cellDoubleClicked, this, [this](int row, int column) {
            if (column == 1) { // Verifică dacă coloana este "Denumire"
                onCellDoubleClicked(row, column);
            }
        });

        socket->disconnectFromHost();
        if (socket->state() == QAbstractSocket::ConnectedState) {
            socket->waitForDisconnected();
        }
    }
    else
    {
        qDebug()<<"Eroare conectare la server.";
    }
    }
}


void CautaProdus::onCellDoubleClicked(int row, int column) {
    // Obține denumirea produsului din celula dublu clicată
    denumireProdus = tableWidget->item(row, 1)->text();
    cod= tableWidget->item(row,0)->text();

    // Creează și afișează fereastra/widget-ul nou
    OptiuniProdus *optiuniWidget = new OptiuniProdus(denumireProdus,cod);
    a->scrieMesaj("Se efetueaza operatiuni pentru produsul "+this->denumireProdus);
    this->hide();
    optiuniWidget->show();
}



void CautaProdus::on_bInapoi_clicked()
{
    AngajatMainPage* angajat= new AngajatMainPage();
    this->hide();
    angajat->show();
}




