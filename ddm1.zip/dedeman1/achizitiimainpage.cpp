#include "achizitiimainpage.h"
#include "adaugaprodus.h"
#include "ui_achizitiimainpage.h"
#include "mainwindow.h"
#include "stergeprodus.h"
#include "cautaprodus.h"
#include "adaugaangajat.h"
#include "modificarestoc.h"

AchizitiiMainPage::AchizitiiMainPage(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::AchizitiiMainPage)
{
    ui->setupUi(this);
    setWindowTitle("Administrator");
    QPixmap pix("C:/Users/sebas/Downloads/GheSku.jpg");
    ui->label_pic->setPixmap(pix.scaled(201,201,Qt::KeepAspectRatio));
    setWindowIcon(QIcon("C:/Users/sebas/Downloads/GheSku.jpg"));
    QPixmap backgroundImage("C:/Users/sebas/OneDrive/Desktop/fundal1.jpg");
    QPalette palette;
    palette.setBrush(QPalette::Window, backgroundImage);
    this->setStyleSheet("MainWindow { background-image: url(C:/Users/sebas/OneDrive/Desktop/fundal1.jpg); }");
    this->setPalette(palette);
}

AchizitiiMainPage::~AchizitiiMainPage()
{
    delete ui;
}

void AchizitiiMainPage::on_bInsert_clicked()
{
    AdaugaProdus* adaugaprodus= new AdaugaProdus();
    this->hide();
    adaugaprodus->show();
}


void AchizitiiMainPage::on_btInapoi_clicked()
{
    MainWindow* main= new MainWindow();
    this->hide();
    main->show();
    a->scrieMesaj("Administrtorul s-a deconectat");
}


void AchizitiiMainPage::on_bSterge_clicked()
{
    StergeProdus* sterge= new StergeProdus();
    this->hide();
    sterge->show();
}


void AchizitiiMainPage::on_bCauta_clicked()
{
    this->hide();
    CautaProdus* cp=new CautaProdus();
    cp->show();
}


void AchizitiiMainPage::on_bAddAngajat_clicked()
{
    AdaugaAngajat* add=new AdaugaAngajat();
    this->hide();
    add->show();
}


void AchizitiiMainPage::on_bModStoc_clicked()
{
    ModificareStoc* ms=new ModificareStoc();
    this->hide();
    ms->show();
}

