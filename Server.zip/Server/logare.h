
#ifndef LOGARE_H
#define LOGARE_H
#include <QString>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>

class Logare
{
public:
    Logare(){}
    bool checkCredentials(const QString &username, const QString &password);
    bool checkAdministrator(const QString &username);
    ~Logare(){}
private:
    QString functie,magazin;
};

#endif // LOGARE_H
