
#include "myserver.h"




void MyServer::clearSocket()
{
    socket = qobject_cast<QTcpSocket *>(sender());
    socket->flush();
    socket->disconnectFromHost();
    socket->deleteLater();
}

void MyServer::onNewConnection()
{
    while (hasPendingConnections()) {
        socket = nextPendingConnection();
        connect(socket, &QTcpSocket::readyRead, this, &MyServer::onReadyRead);
    }
}


void MyServer::onReadyRead()
{

    socket = qobject_cast<QTcpSocket *>(sender());
    if (socket) {
        QByteArray data = socket->readAll();
        qDebug() << "Date primite de la client: " << data;

        QStringList parts = QString(data).split(":");
        parts7(parts);
        parts3(parts);
        parts2(parts);
        parts5(parts);
        parts4(parts);
    }
}

void MyServer::adaugareProdus()
{
    if(codOperatiune=="700") //adaugare produs
    {
        QSqlDatabase db = QSqlDatabase::addDatabase("QODBC");
        db.setDatabaseName("Driver={ODBC Driver 17 for SQL Server};Server=DESKTOP-H86O4FU;Database=Dedeman;Trusted_Connection=yes;");
        if(db.open())
        {
            qDebug()<<"Se verifica daca produsul exista deja in magazin...";
            //qDebug()<<codprodus;
            QSqlQuery query,query1,query2,query3,query4,query5,query6;
            //int verifica;
            query1.prepare("SELECT CodProdus FROM [" + magazin + "] WHERE CodProdus = :codprodus");
            query1.bindValue(":codprodus",icodprodus);
            bool check = false;
            if(query1.exec())
            {
                if(query1.next()) // verifică dacă există cel puțin un rând valid în setul de rezultate
                {
                    icodprodus = query1.value(0).toInt(); // citește valoarea primei coloane
                    qDebug() << icodprodus;
                    qDebug()<<"A fost identificat un produs cu acelasi cod...";
                    check= true;
                }
                else
                {
                    qDebug() << "Nu s-a gasit niciun produs cu codul specificat.";
                }
            }
            else
            {
                qDebug() << "Eroare la executare query.";
            }
            if(check==false)
            {
                qDebug()<<"Se adauga produsul "<<denumire<<" produs de "<<producator<<" in stocul magazinului "<<magazin;
                query.prepare("INSERT INTO [" + magazin + "] VALUES (:codprodus,:denumire,:producator,:pret,:stoc)");

                query.bindValue(":denumire",denumire);
                query.bindValue(":codprodus",icodprodus);
                query.bindValue(":producator",producator);
                query.bindValue(":pret",pret);
                query.bindValue(":stoc",istoc);

                if(magazin=="Magazin 3 Baneasa")
                {
                    query1.prepare("INSERT INTO [Magazin 40 Pantelimon] VALUES (:codprodus,:denumire,:producator,:pret,:stoc)");
                    query2.prepare("INSERT INTO [Magazin 91 Ghencea] VALUES (:codprodus,:denumire,:producator,:pret,:stoc)");
                    query1.bindValue(":denumire",denumire);
                    query1.bindValue(":codprodus",icodprodus);
                    query1.bindValue(":producator",producator);
                    query1.bindValue(":pret",pret);
                    query1.bindValue(":stoc",0);
                    query2.bindValue(":denumire",denumire);
                    query2.bindValue(":codprodus",icodprodus);
                    query2.bindValue(":producator",producator);
                    query2.bindValue(":pret",pret);
                    query2.bindValue(":stoc",0);
                    if(query1.exec() && query2.exec())
                    {
                        qDebug()<<"1-Produsele au fost adaugate in celelalte magazin cu stoc 0...";
                    }
                    else
                    {
                        qDebug()<<"1-Produsele nu au fost adaugate si in celelalte magazine...";
                    }
                }
                if(magazin=="Magazin 40 Pantelimon")
                {
                    query3.prepare("INSERT INTO [Magazin 3 Baneasa] VALUES (:codprodus,:denumire,:producator,:pret,:stoc)");
                    query4.prepare("INSERT INTO [Magazin 91 Ghencea] VALUES (:codprodus,:denumire,:producator,:pret,:stoc)");
                    query3.bindValue(":denumire",denumire);
                    query3.bindValue(":codprodus",icodprodus);
                    query3.bindValue(":producator",producator);
                    query3.bindValue(":pret",pret);
                    query3.bindValue(":stoc",0);
                    query4.bindValue(":denumire",denumire);
                    query4.bindValue(":codprodus",icodprodus);
                    query4.bindValue(":producator",producator);
                    query4.bindValue(":pret",pret);
                    query4.bindValue(":stoc",0);
                    if(query3.exec() && query4.exec())
                    {
                        qDebug()<<"2-Produsele au fost adaugate in celelalte magazin cu stoc 0...";
                    }
                    else
                    {
                        qDebug()<<"2-Produsele nu au fost adaugate si in celelalte magazine...";
                    }
                }
                if(magazin=="Magazin 91 Ghencea")
                {
                    query5.prepare("INSERT INTO [Magazin 3 Baneasa] VALUES (:codprodus,:denumire,:producator,:pret,:stoc)");
                    query6.prepare("INSERT INTO [Magazin 40 Pantelimon] VALUES (:codprodus,:denumire,:producator,:pret,:stoc)");
                    query5.bindValue(":denumire",denumire);
                    query5.bindValue(":codprodus",icodprodus);
                    query5.bindValue(":producator",producator);
                    query5.bindValue(":pret",pret);
                    query5.bindValue(":stoc",0);
                    query6.bindValue(":denumire",denumire);
                    query6.bindValue(":codprodus",icodprodus);
                    query6.bindValue(":producator",producator);
                    query6.bindValue(":pret",pret);
                    query6.bindValue(":stoc",0);
                    if(query5.exec() && query6.exec())
                    {
                        qDebug()<<"3-Produsele au fost adaugate in celelalte magazin cu stoc 0...";
                    }
                    else
                    {
                        qDebug()<<"3-Produsele nu au fost adaugate si in celelalte magazine...";
                    }
                }

                if(query.exec())
                {
                    qDebug()<<"A fost adaugat produsul de mai sus cu succes";
                    socket->write("700 succes");
                }
            }
            else
            {
                socket->write("700 duplicat");
                qDebug()<<"Eroare la adaugarea produsului.";
            }
        }
        db.close();
    }
    else
    {
        qDebug()<<"Operatiune nerecunoscuta";
    }
}
void MyServer::autentificare(const QStringList &parts)
{
    if(codOperatiune=="0") //autentificarea
    {
        qDebug()<<"Se efectueaza logarea in aplicatie...";
        username=text1;
        password=text2;
        if (a->checkCredentials(username,password)) {
            if(a->checkAdministrator(username)){
                socket->write("autentificat ca si Administrator");
                qDebug()<<"Autentificare reusita >>> Administrator";
            }
            else
            {
                socket->write("autentificat ca si Lucrator comercial");
                qDebug()<<"Autentificare reusita >>> Lucrator comercial";
            }
        } else {
            socket->write("neautentificat");
            qDebug()<<"Autentificare esuata...";
        }
        qDebug() << "Partile dupa autentificare: " << parts;
        clearSocket();
    }
}
void MyServer::stergereProdus()
{
    if(codOperatiune=="701") // stergere produs
    {
        codprodus1=text1;
        icodprodus=codprodus1.toInt();
        magazin=text2;
        qDebug()<<"Se sterge produsul cu codul "<<codprodus<<" din magazinul "<<magazin;
        QSqlDatabase db = QSqlDatabase::addDatabase("QODBC");
        db.setDatabaseName("Driver={ODBC Driver 17 for SQL Server};Server=DESKTOP-H86O4FU;Database=Dedeman;Trusted_Connection=yes;");
        if(db.open())
        {
            QSqlQuery query,query1;
            qDebug()<<"Se verifica daca produsul exista deja in magazin...";
            //qDebug()<<codprodus;
            //int verifica;
            query1.prepare("SELECT CodProdus FROM [" + magazin + "] WHERE CodProdus = :codprodus");
            query1.bindValue(":codprodus",codprodus);
            bool check = false;
            if(query1.exec())
            {
                if(query1.next()) // verifică dacă există cel puțin un rând valid în setul de rezultate
                {
                    int cod = query1.value(0).toInt(); // citește valoarea primei coloane
                    qDebug() << cod;
                    qDebug()<<"A fost identificat un produs cu acelasi cod...";
                    check= true;
                }
                else
                {
                    qDebug() << "Nu s-a gasit niciun produs cu codul specificat.";
                    socket->write("701 lipsa");
                }
            }
            else
            {
                qDebug() << "Eroare la executare query.";
            }
            if(check==true)
            {
                qDebug()<<"Se sterge produsul...";
                query.prepare("DELETE FROM [" + magazin + "] WHERE CodProdus = :codprodus");
                query.bindValue(":codprodus",codprodus);
                if(query.exec())
                {
                    qDebug()<<"Produsul cu id "<<codprodus<<" a fost sters cu succes.";
                    socket->write("701 succes");
                }
                else
                {
                    qDebug()<<"Eroare la stergerea produsului.";
                }
            }
        }
        db.close();
    }
}
void MyServer::cautareProdus()
{
    if(codOperatiune=="57"){ //cautare produs dupa denumire
        denumire=text1;
        QSqlDatabase db = QSqlDatabase::addDatabase("QODBC");
        db.setDatabaseName("Driver={ODBC Driver 17 for SQL Server};Server=DESKTOP-H86O4FU;Database=Dedeman;Trusted_Connection=yes;");
        QSqlQuery query;
        QSqlQuery query1;
        QSqlQuery query2;
        QSqlQuery query3;
        if(db.open()){
            query3.prepare("SELECT Denumire FROM [Magazin 3 Baneasa] WHERE Denumire LIKE :denumire");
            query3.bindValue(":denumire","%" + denumire + "%");
            bool check=false;
            if(query3.exec())
            {
                if(query3.next())
                {
                    qDebug()<<"A fost identificat un produs conform cautarii...";
                    check=true;
                }
                else
                {
                    socket->write("57 lipsa");
                    qDebug()<<"Nu exista produsul...";
                }
            }
            else
            {
                qDebug()<<"Eroare executare query";
            }
            if(check==true){
                query.prepare("SELECT CodProdus,Denumire,Producator,Pret,Stoc FROM [Magazin 3 Baneasa] WHERE Denumire LIKE :denumire");
                query.bindValue(":denumire", "%" + denumire + "%");
                query1.prepare("SELECT CodProdus,Denumire,Producator,Pret,Stoc FROM [Magazin 91 Ghencea] WHERE Denumire LIKE :denumire");
                query1.bindValue(":denumire", "%" + denumire + "%");
                query2.prepare("SELECT CodProdus,Denumire,Producator,Pret,Stoc FROM [Magazin 40 Pantelimon] WHERE Denumire LIKE :denumire");
                query2.bindValue(":denumire", "%" + denumire + "%");
                if (query.exec() && query1.exec() && query2.exec()) {
                    while (query.next() &&query1.next()&&query2.next()){
                        QString codprodus=query.value(0).toString();
                        QString denumire=query.value(1).toString();
                        QString producator=query.value(2).toString();
                        QString pret=query.value(3).toString();
                        stocBaneasa=query.value(4).toString();
                        stocGhencea=query1.value(4).toString();
                        stocPantelimon=query2.value(4).toString();
                        qDebug()<<codprodus<<" "<<denumire<<" "<<producator<<" "<<pret<<" "<<stocBaneasa<<" "<<stocGhencea<<" "<<stocPantelimon;
                        QStringList result = {codprodus, denumire, producator, pret, stocBaneasa,stocGhencea,stocPantelimon,"\n"};
                        QString response = result.join(",");
                        socket->write(response.toUtf8());
                    }
                }
                else
                {
                    qDebug()<<"Error executing query: "<<query.lastError().text();
                }
            }
        }
        db.close();
    }
}
void MyServer::cautareProdusIndividual()
{
    if(codOperatiune=="421")//rezervare produs per magazin
    {
        magazin=text1;
        QSqlDatabase db = QSqlDatabase::addDatabase("QODBC");
        db.setDatabaseName("Driver={ODBC Driver 17 for SQL Server};Server=DESKTOP-H86O4FU;Database=Dedeman;Trusted_Connection=yes;");
        QSqlQuery query;
        if(db.open())
        {
            query.prepare("SELECT CodProdus,Denumire,Producator,Pret,Stoc FROM ["+magazin+"]");
            if(query.exec())
            {
                while(query.next()){
                    codprodus=query.value(0).toString();
                    denumire=query.value(1).toString();
                    producator=query.value(2).toString();
                    pret=query.value(3).toString();
                    stoc=query.value(4).toString();
                    qDebug()<<codprodus<<" "<<denumire<<" "<<producator<<" "<<pret<<" "<<stoc;
                    QString response = QString("%1:%2:%3:%4:%5:").arg(codprodus,denumire,producator,pret,stoc).toUtf8();
                    socket->write(response.toUtf8());
                }
            }
        }
        db.close();
    }
}
void MyServer::rezervareProdus1()
{
    if(codOperatiune=="425") // rezervare produs dreapta
    {
        denumire=text1;
        codprodus1=text2;
        icodprodus=codprodus1.toInt();
        magazin=text3;
        bucati1=text4;
        ibucati=bucati1.toInt();
        QSqlDatabase db = QSqlDatabase::addDatabase("QODBC");
        db.setDatabaseName("Driver={ODBC Driver 17 for SQL Server};Server=DESKTOP-H86O4FU;Database=Dedeman;Trusted_Connection=yes;");

        if(db.open())
        {
            qDebug()<<"Se verifica disponibilitatea in magazin...";
            qDebug()<<icodprodus;
            QSqlQuery query,query1;
            //int verifica;
            query.prepare("SELECT Stoc FROM [" + magazin + "] WHERE CodProdus = :codprodus");
            query.bindValue(":codprodus",icodprodus);
            bool check = false;
            bool check2=false;
            if(query.exec())
            {
                if(query.next()) // verifică dacă există cel puțin un rând valid în setul de rezultate
                {
                    istoc = query.value(0).toInt(); // citește valoarea primei coloane
                    qDebug() << istoc;
                    if(istoc==0)
                    {
                        check= true;
                    }
                    if(istoc<ibucati)
                    {
                        check2=true;
                    }
                }
            }
            else
            {
                qDebug() << "Eroare la executare query.";
            }
            if(check==false && check2==false)
            {
                qDebug()<<"Se efectueaza rezervarea "<<denumire<<" in magazinul "<<magazin;
                query1.prepare("UPDATE [" + magazin + "] SET Stoc = :stoc-:bucati WHERE CodProdus=:codprodus");
                query1.bindValue(":stoc",istoc);
                query1.bindValue(":codprodus",icodprodus);
                query1.bindValue(":bucati",ibucati);

                if(query1.exec())
                {
                    qDebug()<<"Rezervarea a fost efectuata cu succes";
                    socket->write("425 succes");
                }
            }
            else
            {
                if(check==true){
                    socket->write("425 indisponibil");
                    qDebug()<<"Produs indisponibil...Eroare la rezervarea produsului";
                }
                if(check2==true)
                {
                    socket->write("425 insuficient");
                    qDebug()<<"Stoc insuficient pentru rezervare...";
                }
            }
        }
        db.close();
    }
}
void MyServer::creareContAngajat()
{
    if(codOperatiune=="800") //creare cont nou angajat
    {
        username=text1;
        password=text2;
        functie=text3;
        magazin=text4;
        qDebug()<<"Se creeaza contul noului angajat...";
        QSqlDatabase db = QSqlDatabase::addDatabase("QODBC");
        db.setDatabaseName("Driver={ODBC Driver 17 for SQL Server};Server=DESKTOP-H86O4FU;Database=Dedeman;Trusted_Connection=yes;");
        if(db.open())
        {
            QSqlQuery query;
            query.prepare("INSERT INTO Conturi (Magazin, Username, Parola, Functie) VALUES (:magazin,:username,:parola,:functie)");
            query.bindValue(":username",username);
            query.bindValue(":parola",password);
            query.bindValue(":functie",functie);
            query.bindValue(":magazin",magazin);
            if(query.exec())
            {
                qDebug()<<"Contul a fost adaugat cu succes.";
                socket->write("800 succes");
            }
            else
            {
                qDebug()<<"Eroare la executarea query...";
                qDebug()<<"Contul nu a fost adaugat";
            }
        }
        db.close();
    }
}
void MyServer::rezervareProdus2()
{
    if(codOperatiune=="420")//rezervare
    {
        denumire=text1;
        codprodus1=text2;
        icod=codprodus1.toInt();
        magazin=text3;
        QSqlDatabase db = QSqlDatabase::addDatabase("QODBC");
        db.setDatabaseName("Driver={ODBC Driver 17 for SQL Server};Server=DESKTOP-H86O4FU;Database=Dedeman;Trusted_Connection=yes;");

        if(db.open())
        {
            qDebug()<<"Se verifica disponibilitatea in magazin...";
            //qDebug()<<codprodus;
            QSqlQuery query,query1;
            //int verifica;
            query1.prepare("SELECT Stoc FROM [" + magazin + "] WHERE CodProdus = :codprodus");
            query1.bindValue(":codprodus",icod);
            bool check = false;
            if(query1.exec())
            {
                if(query1.next()) // verifică dacă există cel puțin un rând valid în setul de rezultate
                {
                    istoc = query1.value(0).toInt(); // citește valoarea primei coloane
                    qDebug() << istoc;
                    if(istoc==0)
                    {
                        check= true;
                    }
                }
            }
            else
            {
                qDebug() << "Eroare la executare query.";
            }
            if(check==false)
            {
                qDebug()<<"Se efectueaza rezervarea "<<denumire<<" in magazinul "<<magazin;
                query.prepare("UPDATE [" + magazin + "] SET Stoc = :stoc-1 WHERE CodProdus=:codprodus");
                query.bindValue(":stoc",istoc);
                query.bindValue(":codprodus",icod);

                if(query.exec())
                {
                    qDebug()<<"Rezervarea a fost efectuata cu succes";
                    socket->write("420 succes");
                }
            }
            else
            {
                socket->write("420 indisponibil");
                qDebug()<<"Eroare la rezervarea produsului";
            }
        }
        db.close();
    }
}
void MyServer::modificareStoc()
{
    if(codOperatiune=="900")//modificare stoc
    {
        codprodus1=text1;
        icodprodus=codprodus1.toInt();
        stoc1=text2;
        magazin=text3;
        istoc=stoc1.toInt();
        qDebug()<<"Se modifica stocul produsului in magazinul "<<magazin;
        QSqlDatabase db = QSqlDatabase::addDatabase("QODBC");
        db.setDatabaseName("Driver={ODBC Driver 17 for SQL Server};Server=DESKTOP-H86O4FU;Database=Dedeman;Trusted_Connection=yes;");
        if(db.open())
        {
            QSqlQuery query,query1;
            bool check=false;
            query1.prepare("SELECT CodProdus FROM ["+ magazin + "] WHERE Codprodus=:codprodus");
            query1.bindValue(":codprodus",icodprodus);
            if(query1.exec())
            {
                if(query1.next())
                {
                    check=true;
                }
                else
                {
                    qDebug()<<"Cod inexistent pentru modificare";
                    socket->write("900 inexistent");
                }
            }
            else
            {
                qDebug()<<"Eroare executare query.";
            }
            if(check==true){
            query.prepare("UPDATE [" + magazin + "] SET Stoc=:stoc WHERE CodProdus=:codprodus");
            query.bindValue(":codprodus",icodprodus);
            query.bindValue(":stoc",istoc);
            if(query.exec())
            {
                qDebug()<<"Stocul a fost modificat...";
                socket->write("900 succes");
            }
            else
            {
                socket->write("900 eroare");
                qDebug()<<"Eroare la executarea query...";
                qDebug()<<"Stocul nu a fost modificat...";
            }
        }
        }
        db.close();
    }
}


void MyServer::parts7( const QStringList &parts)
{
    if(parts.size()==7){
        denumire=parts[0];
        codprodus1=parts[1];
        icodprodus=codprodus1.toInt();
        producator=parts[2];
        pret1=parts[3];
        fpret2=pret1.toFloat();
        pret = QString::number(fpret2, 'f', 2);
        stoc1=parts[4];
        istoc=stoc1.toInt();
        magazin=parts[5];
        codOperatiune=parts[6];
        qDebug()<<denumire<<" "<<icodprodus<<" "<<producator<<" "<<pret<<" "<<istoc<<" "<<magazin<<" "<<codOperatiune;

        adaugareProdus();
    }

}
void MyServer::parts3(const QStringList &parts)
{
    if(parts.size()==3) {
        QSqlDatabase db = QSqlDatabase::addDatabase("QODBC");
        text1 = parts[0];
        text2 = parts[1];
        codOperatiune=parts[2];
        autentificare(parts);
        stergereProdus();
    }

}
void MyServer::parts2(const QStringList &parts)
{
    if(parts.size()==2){
        text1=parts[0];
        codOperatiune=parts[1];
        cautareProdus();
        cautareProdusIndividual();
    }

}
void MyServer::parts5(const QStringList &parts)
{
    if(parts.size()==5)
    {
        text1=parts[0];
        text2=parts[1];
        text3=parts[2];
        text4=parts[3];
        codOperatiune=parts[4];
        creareContAngajat();
        rezervareProdus1();

    }

}
void MyServer::parts4(const QStringList &parts)
{
    if(parts.size()==4)
    {
        text1=parts[0];
        text2=parts[1];
        text3=parts[2];
        codOperatiune=parts[3];
        rezervareProdus2();
        modificareStoc();

    }

}
