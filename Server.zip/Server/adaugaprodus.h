
#ifndef ADAUGAPRODUS_H
#define ADAUGAPRODUS_H


class AdaugaProdus
{
public:
    AdaugaProdus();
    ~AdaugaProdus();
};

#endif // ADAUGAPRODUS_H
