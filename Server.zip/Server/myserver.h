
#ifndef MYSERVER_H
#define MYSERVER_H

#include <QTcpServer>
#include <QTcpSocket>
#include "logare.h"
#include <QCoreApplication>
#include <QByteArray>

class MyServer: public QTcpServer
{
public:

    Logare* a=new Logare();
    MyServer(QObject *parent = nullptr) : QTcpServer(parent) {
        connect(this, &QTcpServer::newConnection, this, &MyServer::onNewConnection);
    }
private:
    QTcpSocket* socket=new QTcpSocket();
    QString denumire,codprodus,codprodus1,codOperatiune,producator,pret,pret1,stoc1,magazin,username,password,functie,stoc,bucati1;
    QString text1,text2,text3,text4;
    QString stocBaneasa,stocGhencea,stocPantelimon;
    int icodprodus,istoc,ibucati,icod;
    float fpret2;
protected:
    void clearSocket();

    void onNewConnection();

    void onReadyRead();
    void adaugareProdus();
    void autentificare(const QStringList &parts);
    void stergereProdus();
    void cautareProdus();
    void cautareProdusIndividual();
    void creareContAngajat();
    void rezervareProdus1();
    void rezervareProdus2();
    void modificareStoc();

    void parts7(const QStringList& parts);
    void parts3(const QStringList& parts);
    void parts2(const QStringList& parts);
    void parts5(const QStringList& parts);
    void parts4(const QStringList& parts);

};

#endif // MYSERVER_H
