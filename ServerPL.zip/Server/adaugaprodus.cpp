#include "adaugaprodus.h"

AdaugaProdus::AdaugaProdus()
{

}

