
#include <logare.cpp>

#include "myserver.h"


int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    MyServer server;
    if (!server.listen(QHostAddress::Any, 1234)) {
        qDebug() << "Failed to start server:" << server.errorString();
        return -1;
    }
    qDebug() << "Server listening on port" << server.serverPort();

    return a.exec();
}
