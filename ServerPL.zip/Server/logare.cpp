#include "logare.h"

bool Logare::checkCredentials(const QString &username, const QString &password)
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QODBC");
    db.setDatabaseName("Driver={ODBC Driver 17 for SQL Server};Server=DESKTOP-KOA7NMO;Database=Dedeman;Trusted_Connection=yes;");
    if(db.open())
    {
        QSqlQuery query;
        query.prepare("SELECT * FROM Conturi WHERE username = :username AND passwd = :password");
        query.bindValue(":username", username);
        query.bindValue(":password", password);
        if (query.exec()) {
            return query.next(); // Returnează adevărat dacă s-a găsit cel puțin un rând
        } else {
            qDebug() << "Eroare la executarea interogării:" << query.lastError().text();
                                                               return false;
        }
    }
    db.close();
    return false;
}


bool Logare::checkAdministrator(const QString &username)
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QODBC");
    db.setDatabaseName("Driver={ODBC Driver 17 for SQL Server};Server=DESKTOP-KOA7NMO;Database=Dedeman;Trusted_Connection=yes;");
    if (db.open()) {
        QSqlQuery query;
        query.prepare("SELECT functie,magazin FROM Conturi WHERE username = :username");
        query.bindValue(":username", username);
        if (query.exec() && query.next()) {
            functie = query.value(0).toString();
            return (functie == "Administrator");
        } else {
            qDebug() << "Eroare la executarea interogării:" << query.lastError().text();
        }
    } else {
        qDebug() << "Eroare la conectarea la baza de date:" << db.lastError().text();
    }
    db.close();
    return false;
}
