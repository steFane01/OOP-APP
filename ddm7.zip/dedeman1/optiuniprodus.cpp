#include "optiuniprodus.h"
#include "ui_optiuniprodus.h"
#include <QMessageBox>
#include <QTimer>


OptiuniProdus::OptiuniProdus(const QString& denumireProdus,const QString& cod, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::OptiuniProdus)
{
    ui->setupUi(this);
    setWindowTitle("Rezervare Produs");
    setWindowIcon(QIcon("C:/Users/sebas/Downloads/GheSku.jpg"));
    ui->lineDenumire->setText(denumireProdus);
    ui->lineCod->setText(cod);
}

OptiuniProdus::~OptiuniProdus()
{
    delete ui;
}

void OptiuniProdus::on_bRezerva_clicked()
{
    socket->connectToHost("127.0.0.1",1234);

    if (socket->waitForConnected()) {
        numeProdus=ui->lineDenumire->text();
        cod=ui->lineCod->text();
        magazin=ui->comboMagazin->currentText();

        ui->lineDenumire->clear();
        ui->lineCod->clear();

        codOperatiune = "420";
        QByteArray data = QString("%1:%2:%3:%4").arg(numeProdus,cod,magazin,codOperatiune).toUtf8();
        socket->write(data);
        socket->waitForBytesWritten();

        socket->waitForReadyRead();
        QByteArray responseData = socket->readAll();
        QString responseString(responseData);
        qDebug()<<responseString;
        if(responseString=="420 succes")
        {
            QMessageBox* msgBox = new QMessageBox(QMessageBox::Information, "Rezervare produs", "Produs rezervat cu succes");
            a->scrieMesaj("A fost rezervat prodosul "+this->numeProdus+" in "+this->magazin);
            msgBox->setWindowTitle("Rezervare produs");

            // Setam butonul implicit sa nu fie afisat
            msgBox->setDefaultButton(QMessageBox::NoButton);
            msgBox->setStyleSheet("QMessageBox {background-color: #F4661B;}");
            QTimer::singleShot(1000, msgBox, &QMessageBox::accept); // 5000 ms = 5 secunde
            msgBox->exec();
        }
        if(responseString=="420 indisponibil")
        {
            QMessageBox* msgBox = new QMessageBox(QMessageBox::Information, "Rezervare produs", "Produsul nu este disponibil in acest magazin");
            msgBox->setWindowTitle("Rezervare Produs");
            a->scrieMesaj("S-a incercat o rezervare pentru produsul "+this->numeProdus+" in "+this->magazin+" acesta fiind indisponibil");
            // Setam butonul implicit sa nu fie afisat
            msgBox->setDefaultButton(QMessageBox::NoButton);
            msgBox->setStyleSheet("QMessageBox {background-color: #F4661B;}");
            QTimer::singleShot(1000, msgBox, &QMessageBox::accept); // 5000 ms = 5 secunde
            msgBox->exec();
        }
    }
    else
    {
        qDebug()<<"Eroare conectare la server.";
    }
}

