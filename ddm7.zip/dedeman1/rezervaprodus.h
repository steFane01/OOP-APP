#ifndef REZERVAPRODUS_H
#define REZERVAPRODUS_H

#include <QWidget>
#include <QTcpSocket>
#include <QTableWidget>
#include <QHeaderView>
#include <QVBoxLayout>
#include "logger.h"
namespace Ui {
class RezervaProdus;
}

class RezervaProdus : public QWidget
{
    Q_OBJECT

public:
    explicit RezervaProdus(QWidget *parent = nullptr);
    ~RezervaProdus();

private slots:

    void onCellDoubleClicked(int row, int column);

    void on_bRezerva_clicked();

    void on_bInapoi_clicked();

private:
    Ui::RezervaProdus *ui;
    QTcpSocket* socket = new QTcpSocket();
    QTableWidget *tableWidget;
    QString denumireProdus,cod,magazin;
    logger* a=new logger();

};

#endif // REZERVAPRODUS_H
