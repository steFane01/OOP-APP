#ifndef ACHIZITIIMAINPAGE_H
#define ACHIZITIIMAINPAGE_H

#include <QMainWindow>
#include <QTcpSocket>
#include "logger.h"

namespace Ui {
class AchizitiiMainPage;
}

class AchizitiiMainPage : public QMainWindow
{
    Q_OBJECT

public:
    explicit AchizitiiMainPage(QWidget *parent = nullptr);
    ~AchizitiiMainPage();

private slots:
    void on_bInsert_clicked();

    void on_btInapoi_clicked();

    void on_bSterge_clicked();

    void on_bCauta_clicked();

    void on_bAddAngajat_clicked();

    void on_bModStoc_clicked();

private:
    Ui::AchizitiiMainPage *ui;
    QTcpSocket* socket = new QTcpSocket();
    logger* a=new logger();
};

#endif // ACHIZITIIMAINPAGE_H
