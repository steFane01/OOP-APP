#include "rezervaprodus.h"
#include "optiuniprodus2.h"
#include "angajatmainpage.h"
#include "ui_rezervaprodus.h"

RezervaProdus::RezervaProdus(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::RezervaProdus)
{
    ui->setupUi(this);
    setWindowTitle("Rezervare Produs");
    setWindowIcon(QIcon("C:/Users/sebas/Downloads/GheSku.jpg"));
}

RezervaProdus::~RezervaProdus()
{
    delete ui;
}

void RezervaProdus::onCellDoubleClicked(int row, int column) {
    // Obține denumirea produsului din celula dublu clicată
    denumireProdus = tableWidget->item(row, 1)->text();
    cod= tableWidget->item(row,0)->text();
    magazin=ui->comboMagazin->currentText();

    // Creează și afișează fereastra/widget-ul nou
    OptiuniProdus2 *optiuniWidget2 = new OptiuniProdus2(denumireProdus,cod,magazin);
    optiuniWidget2->show();

    this->hide();

}

void RezervaProdus::on_bRezerva_clicked()
{
    socket = new QTcpSocket(this);
    socket->connectToHost("127.0.0.1", 1234);
    if (socket->waitForConnected()) {
        QString magazin=ui->comboMagazin->currentText();
        QString codOperatiune = "421";
        QByteArray data = QString("%1:%2").arg(magazin, codOperatiune).toUtf8();
        socket->write(data);
        socket->waitForBytesWritten();

        socket->waitForReadyRead();
        QByteArray responseData = socket->readAll();
        QString responseString(responseData);
        QStringList splitResult = responseString.split(":");
        qDebug()<<responseData;
        // Crearea QTableWidget și setarea numărului de rânduri și coloane
        tableWidget = new QTableWidget(splitResult.size() / 5, 5, this);
        tableWidget->setHorizontalHeaderLabels({"Cod", "Denumire", "Producator", "Pret", "Stoc"});
        tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

        int currentRow = 0;
        int currentColumn = 0;
        for (int i = 0; i < splitResult.size(); i++) {
            QString currentString = splitResult.at(i);
            QTableWidgetItem *item = new QTableWidgetItem(currentString.trimmed());
            tableWidget->setItem(currentRow, currentColumn, item);

            if (currentColumn == 4) {
                currentRow++;
                currentColumn = 0;
            } else {
                currentColumn++;
            }
        }

        // Redimensionează coloanele pentru a afișa conținutul complet
        tableWidget->resizeColumnsToContents();

        QWidget *window = new QWidget;
        QVBoxLayout *layout = new QVBoxLayout(window);
        layout->addWidget(tableWidget);
        window->setLayout(layout);

        int width = tableWidget->horizontalHeader()->length() + 1000;
        int height = tableWidget->verticalHeader()->length() + tableWidget->horizontalHeader()->height() + 200;
        window->resize(width, height);
        window->show();

        // Conectează semnalul cellDoubleClicked doar pentru coloana "Denumire"
        connect(tableWidget, &QTableWidget::cellDoubleClicked, this, [this](int row, int column) {
            if (column == 1) { // Verifică dacă coloana este "Denumire"
                onCellDoubleClicked(row, column);
            }
        });

        socket->disconnectFromHost();
        if (socket->state() == QAbstractSocket::ConnectedState) {
            socket->waitForDisconnected();
        }
    }
    else
    {
        qDebug()<<"Eroare conectare la server.";
    }
    this->hide();
}


void RezervaProdus::on_bInapoi_clicked()
{
    AngajatMainPage* ang=new AngajatMainPage();
    this->hide();
    ang->show();
}

