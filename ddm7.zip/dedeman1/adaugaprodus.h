#ifndef ADAUGAPRODUS_H
#define ADAUGAPRODUS_H

#include <QWidget>
#include <QTcpSocket>
#include "logger.h"

namespace Ui {
class AdaugaProdus;
}

class AdaugaProdus : public QWidget
{
    Q_OBJECT

public:
    explicit AdaugaProdus(QWidget *parent = nullptr);
    ~AdaugaProdus();

private slots:
    void on_butonadauga_clicked();
    void on_butoninapoi_clicked();
    void trimiteMesaj();

private:
    Ui::AdaugaProdus *ui;
    QTcpSocket* socket = new QTcpSocket();
    QString denumire,codprodus,producator,pret,stoc,magazin,codOperatiune;
    logger* a=new logger();

};

#endif // ADAUGAPRODUS_H
