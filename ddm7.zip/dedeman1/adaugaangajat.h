#ifndef ADAUGAANGAJAT_H
#define ADAUGAANGAJAT_H

#include <QWidget>
#include <QTcpSocket>
#include "logger.h"

namespace Ui {
class AdaugaAngajat;
}

class AdaugaAngajat : public QWidget
{
    Q_OBJECT

public:
    explicit AdaugaAngajat(QWidget *parent = nullptr);
    ~AdaugaAngajat();

private slots:
    void on_butonadauga_clicked();

    void on_btInapoi_clicked();

private:
    Ui::AdaugaAngajat *ui;
    QTcpSocket* socket= new QTcpSocket();
    logger* a=new logger();
    QString username,parola,checkParola,functie,magazin,codOperatiune;
};

#endif // ADAUGAANGAJAT_H
