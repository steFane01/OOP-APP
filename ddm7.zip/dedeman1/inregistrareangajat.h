#ifndef INREGISTRAREANGAJAT_H
#define INREGISTRAREANGAJAT_H

#include <QWidget>
#include "logger.h"

namespace Ui {
class InregistrareAngajat;
}

class InregistrareAngajat : public QWidget
{
    Q_OBJECT

public:
    explicit InregistrareAngajat(QWidget *parent = nullptr);
    ~InregistrareAngajat();

private:
    Ui::InregistrareAngajat *ui;
    logger* a=new logger();

};

#endif // INREGISTRAREANGAJAT_H
