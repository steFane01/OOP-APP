#include "optiuniprodus2.h"
#include "ui_optiuniprodus2.h"
#include "rezervaprodus.h"
#include <QMessageBox>
#include <QTimer>


OptiuniProdus2::OptiuniProdus2(const QString& denumireProdus,QString& cod,QString& magazin, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::OptiuniProdus2)
{
    ui->setupUi(this);
    setWindowTitle("Rezervare Produs");
    setWindowIcon(QIcon("C:/Users/sebas/Downloads/GheSku.jpg"));
    denumire=denumireProdus;
    codProdus=cod;
    magazin1=magazin;
}

OptiuniProdus2::~OptiuniProdus2()
{
    delete ui;
}

void OptiuniProdus2::on_bRezerva_clicked()
{
    socket->connectToHost("127.0.0.1",1234);

    if (socket->waitForConnected()) {
        bucati=ui->lineBucati->text();

        ui->lineBucati->clear();
        codOperatiune = "425";
        qDebug()<<this->denumire<<" "<<this->codProdus<<" "<<this->magazin1<<" "<<codOperatiune;
        QByteArray data = QString("%1:%2:%3:%4:%5").arg(this->denumire,this->codProdus,this->magazin1,bucati,codOperatiune).toUtf8();
        socket->write(data);
        socket->waitForBytesWritten();

        socket->waitForReadyRead();
        QByteArray responseData = socket->readAll();
        QString responseString(responseData);
        qDebug()<<responseString;
        if(responseString=="425 succes")
        {
            QMessageBox* msgBox = new QMessageBox(QMessageBox::Information, "Rezervare produs", "Produs rezervat cu succes");
            msgBox->setWindowTitle("Rezervare produs");
            a->scrieMesaj("Au fost rezervate "+this->bucati+" bucati de "+this->denumire+" in "+this->magazin1);
            // Setam butonul implicit sa nu fie afisat
            msgBox->setDefaultButton(QMessageBox::NoButton);
            msgBox->setStyleSheet("QMessageBox {background-color: #F4661B;}");
            QTimer::singleShot(1000, msgBox, &QMessageBox::accept); // 5000 ms = 5 secunde
            msgBox->exec();
        }
        if(responseString=="425 indisponibil")
        {
            QMessageBox* msgBox = new QMessageBox(QMessageBox::Information, "Rezervare produs", "Produsul nu este disponibil in acest magazin");
            msgBox->setWindowTitle("Rezervare Produs");

            // Setam butonul implicit sa nu fie afisat
            msgBox->setDefaultButton(QMessageBox::NoButton);
            a->scrieMesaj("S-a incercat rezervare pentru "+this->denumire+" acesta fiind indisponibil in "+this->magazin1);
            msgBox->setStyleSheet("QMessageBox {background-color: #F4661B;}");
            QTimer::singleShot(1000, msgBox, &QMessageBox::accept); // 5000 ms = 5 secunde
            msgBox->exec();
        }

        if(responseString=="425 insuficient")
        {
            QMessageBox* msgBox = new QMessageBox(QMessageBox::Information, "Rezervare produs", "Cantitea este mai mare decat stocul");
            msgBox->setWindowTitle("Rezervare Produs");
            a->scrieMesaj("S-a incercat rezervarea pentru mai multe bucati de "+this->denumire+" decat sunt disponibile in "+this->magazin1);
            // Setam butonul implicit sa nu fie afisat
            msgBox->setDefaultButton(QMessageBox::NoButton);
            msgBox->setStyleSheet("QMessageBox {background-color: #F4661B;}");
            QTimer::singleShot(1000, msgBox, &QMessageBox::accept); // 5000 ms = 5 secunde
            msgBox->exec();
        }
    }
    else
    {
        qDebug()<<"Eroare conectare la server.";
    }
}


void OptiuniProdus2::on_bInapoi_clicked()
{
    RezervaProdus* rzv=new RezervaProdus();
    this->hide();
    rzv->show();
}

