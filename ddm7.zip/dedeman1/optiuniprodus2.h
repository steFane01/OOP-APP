#ifndef OPTIUNIPRODUS_H
#define OPTIUNIPRODUS_H

#include <QWidget>
#include <QTcpSocket>
#include "logger.h"

namespace Ui {
class OptiuniProdus2;
}

class OptiuniProdus2 : public QWidget
{
    Q_OBJECT

public:
    explicit OptiuniProdus2(const QString& denumireProdus,QString& cod,QString& magazin,QWidget *parent = nullptr);
    ~OptiuniProdus2();

private slots:
    void on_bRezerva_clicked();

    void on_bInapoi_clicked();

private:
    Ui::OptiuniProdus2 *ui;
    QTcpSocket* socket = new QTcpSocket();
    QString denumire,codProdus,magazin1,bucati,codOperatiune;
    logger* a=new logger();

};

#endif // OPTIUNIPRODUS_H
