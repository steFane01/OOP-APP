#ifndef STERGEPRODUS_H
#define STERGEPRODUS_H

#include <QWidget>
#include <QTcpSocket>
#include "logger.h"

namespace Ui {
class StergeProdus;
}

class StergeProdus : public QWidget
{
    Q_OBJECT

public:
    explicit StergeProdus(QWidget *parent = nullptr);
    ~StergeProdus();

private slots:

    void on_btnInapoi_clicked();

    void on_bSterge_clicked();

private:
    Ui::StergeProdus *ui;
    QTcpSocket* socket=new QTcpSocket();
    QString codProdus,codOperatiune,magazin;
    logger* a=new logger();

};

#endif // STERGEPRODUS_H
