#include "modificarestoc.h"
#include "achizitiimainpage.h"
#include "ui_modificarestoc.h"

ModificareStoc::ModificareStoc(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ModificareStoc)
{
    ui->setupUi(this);
    setWindowTitle("Modificare Stoc");
    setWindowIcon(QIcon("C:/Users/sebas/Downloads/GheSku.jpg"));
}

ModificareStoc::~ModificareStoc()
{
    delete ui;
}

void ModificareStoc::on_bModifica_clicked()
{
    codprodus = ui->lineCodProdus->text();
    stoc = ui->lineStoc->text();
    magazin = ui->comboBox->currentText();

    ui->lineCodProdus->clear();
    ui->lineStoc->clear();

    codOperatiune = "900";
    this->socket->connectToHost("127.0.0.1",1234);
    if(socket->waitForConnected())
    {
        QByteArray data = QString("%1:%2:%3:%4").arg(codprodus,stoc,magazin,codOperatiune).toUtf8();
        socket->write(data);
        socket->waitForBytesWritten();

        socket->waitForReadyRead();
        QByteArray responseData = socket->readAll();
        QString responseString(responseData);
        qDebug()<<responseData<<" --- "<<responseString;
        if(responseString=="900 succes")
        {
            QMessageBox::information(this,"Modificare Stoc","Stocul produsului a fost modificat cu succes");
            a->scrieMesaj("A fost modificat stocul produsului cu id "+this->codprodus+" noul stoc: "+this->stoc+" in "+this->magazin);
        }
        if(responseString=="900 eroare")
        {
            QMessageBox::information(this,"Modificare Stoc","Stocul produsului nu a fost modificat");
            a->scrieMesaj("S-a incercat modificarea stocului pentru produsul cu id "+this->codprodus+" in "+this->magazin);
        }
    }
    else
    {
        qDebug()<<"Eroare.";
    }
}


void ModificareStoc::on_butoninapoi_clicked()
{
    AchizitiiMainPage* administrator=new AchizitiiMainPage();
    this->hide();
    administrator->show();
}

