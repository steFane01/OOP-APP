#include "logger.h"


logger::logger()
{
    this->cale="C:/Users/sebas/OneDrive/Documente/dedeman1/logger.txt";
}

