#include "adaugaangajat.h"
#include "achizitiimainpage.h"
#include "ui_adaugaangajat.h"
#include <QMessageBox>
#include <QTimer>

AdaugaAngajat::AdaugaAngajat(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AdaugaAngajat)
{
    ui->setupUi(this);
    setWindowIcon(QIcon("C:/Users/sebas/Downloads/GheSku.jpg"));
    ui->linePass->setEchoMode(QLineEdit::Password);
    ui->lineCheckPass->setEchoMode(QLineEdit::Password);
    setWindowTitle("Adaugare Angajat");
}

AdaugaAngajat::~AdaugaAngajat()
{
    delete ui;
}

void AdaugaAngajat::on_butonadauga_clicked()
{
    username=ui->lineUser->text();
    parola=ui->linePass->text();
    checkParola=ui->lineCheckPass->text();
    functie=ui->comboFunctie->currentText();
    magazin=ui->comboMagazin->currentText();

    ui->lineUser->clear();
    ui->lineCheckPass->clear();
    ui->lineUser->clear();
    codOperatiune="800";
    if(parola!=checkParola){
            QMessageBox::information(this,"Inregistrare","Parolele introduse nu corespund");
            return;
        }

    socket->connectToHost("127.0.0.1",1234);
    if(socket->waitForConnected())
    {
        QByteArray data = QString("%1:%2:%3:%4:%5").arg(username,parola,functie,magazin,codOperatiune).toUtf8();
        socket->write(data);
        socket->waitForBytesWritten();

        socket->waitForReadyRead();
        QByteArray responseData = socket->readAll();
        QString responseString(responseData);
        qDebug()<<responseData<<" --- "<<responseString;
        if(responseString=="800 succes")
        {
            QMessageBox* msgBox = new QMessageBox(QMessageBox::Information, "Inregistrare Angajat", "Angajatul a fost adaugat cu succes");
            msgBox->setWindowTitle("Titlu");
            a->scrieMesaj("A fost inregistrat un nou cont pentru angajati de catre "+this->username);
            // Setam butonul implicit sa nu fie afisat
            msgBox->setDefaultButton(QMessageBox::NoButton);
            msgBox->setStyleSheet("QMessageBox {background-color: #F4661B;}");
            QTimer::singleShot(1000, msgBox, &QMessageBox::accept); // 5000 ms = 5 secunde
            msgBox->exec();


        }
        else
        {
            QMessageBox::information(this,"Inregistrare","Angajatul nu a fost inregistrat");
            a->scrieMesaj("S-a incercat inregistrarea unui nou cont pentru angajati de catre "+this->username);
        }
    }
    else
    {
        qDebug()<<"Eroare.";
    }
}


void AdaugaAngajat::on_btInapoi_clicked()
{
    this->hide();
    AchizitiiMainPage* administrator=new AchizitiiMainPage();
    administrator->show();
}

