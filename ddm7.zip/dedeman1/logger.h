#ifndef LOGGER_H
#define LOGGER_H
#include <QString>
#include <QFile>
#include <QTextStream>
#include <QDateTime>
using namespace std;

class logger
{
private:
    QString cale;
public:
    void scrieMesaj(QString mesaj){
        QFile file(this->cale);
        if (!file.open(QIODevice::Append | QIODevice::Text))
            return;
        QTextStream out(&file);
        QDateTime currentDateTime = QDateTime::currentDateTime();
        QString currentDateTimeString = currentDateTime.toString("dd.MM.yyyy HH:mm:ss");
        out <<currentDateTimeString<<" \\ "<<mesaj<<"\n";
        file.close();
    }

    logger();
    ~logger();
};

#endif // LOGGER_H
