#ifndef CAUTAPRODUS_H
#define CAUTAPRODUS_H
#include <QString>
#include <QWidget>
#include <QTcpSocket>
#include <QTableWidget>
#include "logger.h"

namespace Ui {
class CautaProdus;
}

class CautaProdus : public QWidget
{
    Q_OBJECT

public:
    explicit CautaProdus(QWidget *parent = nullptr);
    ~CautaProdus();

private slots:

    void onCellDoubleClicked(int row, int column);

    void on_bCautaProdus_clicked();

    void on_bInapoi_clicked();


private:
    Ui::CautaProdus *ui;
    QTcpSocket* socket=new QTcpSocket();
    QTableWidget *tableWidget;
    QString denumire,codOperatiune,denumireProdus,cod;
    logger* a=new logger();

};

#endif // CAUTAPRODUS_H
