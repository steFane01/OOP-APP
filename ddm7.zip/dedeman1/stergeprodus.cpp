#include "stergeprodus.h"
#include "ui_stergeprodus.h"
#include "achizitiimainpage.h"
#include <QMessageBox>

StergeProdus::StergeProdus(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::StergeProdus)
{
    ui->setupUi(this);
    setWindowTitle("Stergere produs");
    setWindowIcon(QIcon("C:/Users/sebas/Downloads/GheSku.jpg"));
}

StergeProdus::~StergeProdus()
{
    delete ui;
}


void StergeProdus::on_btnInapoi_clicked()
{
    AchizitiiMainPage* administrator=new AchizitiiMainPage();
    this->hide();
    administrator->show();
}


void StergeProdus::on_bSterge_clicked()
{
    codProdus=ui->lineCodProdus->text();
    magazin=ui->comboBox->currentText();

    ui->lineCodProdus->clear();
    codOperatiune="701";

    socket->connectToHost("127.0.0.1",1234);
    if(socket->waitForConnected())
    {
        QByteArray data = QString("%1:%2:%3").arg(codProdus,magazin,codOperatiune).toUtf8();
        socket->write(data);
        socket->waitForBytesWritten();

        socket->waitForReadyRead();
        QByteArray responseData = socket->readAll();
        QString responseString(responseData);
        if(responseString=="701 succes")
        {
            QMessageBox::information(this,"Stergere Produs","Produsul a fost sters cu succes");
            a->scrieMesaj("A fost sters produsul cu id "+this->codProdus+" din "+this->magazin);
        }
        if(responseString=="701 lipsa")
        {
            QMessageBox::information(this,"Stergere produs","Produsul nu exista in gestiunea magazinului");
            a->scrieMesaj("S-a incercat stergerea produsului cu id "+this->codProdus+" din "+this->magazin);
        }

    }
}
