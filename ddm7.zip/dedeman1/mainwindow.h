#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtSql>
#include <QSqlDatabase>
#include <QMessageBox>
#include <QTcpSocket>
#include "logger.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);

    ~MainWindow();

private slots:
    void on_conectare_clicked();
    void onResponseReceived();
private:
    Ui::MainWindow *ui;
    QTcpSocket* socket;
    QString username,parola,password,codOperatiune;
    logger* a=new logger();
};

#endif // MAINWINDOW_H
